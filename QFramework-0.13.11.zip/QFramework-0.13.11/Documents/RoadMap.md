
这里是 QFramework 当前的 **路线图** ，如果想要查看已发布的版本，请点击 [这里](https://github.com/liangxiegame/QFramework/releases)

This is QFrameworks's Roadmap.
[Click here](https://github.com/liangxiegame/QFramework/releases) to check release note.

### v0.0.x: Workflow Explore

#### v0.0.9 QFramework Package Manager [Latest Release]

#### Current v0.0.14
* PackageManager Service Improvement
* doc complete
* qf guidline 2019 book

### v0.1.x: User Service Improvement

### v0.2.x: User Case Collection

### v0.x: Feature Complete

### v1.x: On Asset Store

### Idea

* Blog Article 2 Frameworks Folder

### Research (研究)
* Guidance Framework
* Data Binding
* Visual Scripting,NBP,FBP
* Runtime Simulator 
* Dash Support
* Japanese/Korean Doc Support
* Team Service Support
* CI Support
* Native UI View Ctrl
* Stable Lua Support: [issue#6](https://github.com/liangxiegame/QFramework/issues/6)
