using QFramework.Example;

namespace QFramework
{
	// public partial class QMsgCenter 
	// {
		// partial void ForwardMsg(QMsg msg)
		// {
		// 	switch (msg.ManagerID)
		// 	{
		// 		case QMgrID.Enemy:
		// 			EnemyManager.Instance.SendMsg(msg);
		// 			break;
		// 	}
		// }

	// }
}