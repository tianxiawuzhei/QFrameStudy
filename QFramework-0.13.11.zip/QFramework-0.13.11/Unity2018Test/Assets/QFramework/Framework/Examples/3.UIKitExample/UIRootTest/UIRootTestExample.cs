﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace QFramework.Example
{
	public class UIRootTestExample : MonoBehaviour
	{

		// Use this for initialization
		void Awake()
		{
			var instance = UIRoot.Instance;
		}
	}
}