﻿namespace QFramework
{
    public class MgrID
    {
        public const int Enemy = (QMgrID.FrameworkMsgModuleCount + 1) * QMsgSpan.Count;
    }
}