using System.Collections.Generic;
using Unidux;

namespace QF.DVA
{
    public class ModelDB
    {
        public static Dictionary<string ,IStoreAccessor> DB = new Dictionary<string, IStoreAccessor>();
    }
}