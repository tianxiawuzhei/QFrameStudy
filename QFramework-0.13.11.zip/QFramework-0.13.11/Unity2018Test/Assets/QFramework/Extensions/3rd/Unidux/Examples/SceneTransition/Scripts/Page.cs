﻿namespace Unidux.Example.SceneTransition
{
    public enum Page 
    {
        Page1,
        Page2,
        Page3,
    }
}