﻿namespace Unidux.Example.Todo
{
    public enum VisibilityFilter
    {
        All,
        Active,
        Completed,
    }
}