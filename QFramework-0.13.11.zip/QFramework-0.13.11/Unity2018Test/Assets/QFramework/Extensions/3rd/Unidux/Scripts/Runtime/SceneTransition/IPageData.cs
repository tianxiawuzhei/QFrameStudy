﻿namespace Unidux.SceneTransition
{
    public interface IPageData
    {
    }
}