﻿namespace Unidux
{
    public interface IState
    {
    }
}
