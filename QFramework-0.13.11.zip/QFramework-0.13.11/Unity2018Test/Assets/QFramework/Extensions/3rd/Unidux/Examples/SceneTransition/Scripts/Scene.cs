﻿namespace Unidux.Example.SceneTransition
{
    public enum Scene 
    {
        Base,
        Header,
        Content1,
        Content2,
        Footer,
        Modal,
    }
}