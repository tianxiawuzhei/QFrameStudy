namespace Unidux
{
    public interface IStoreAccessor
    {
        IStoreObject StoreObject { get; }
    }
}