作者：SilenceT     邮箱：499683507@qq.com

# FadeInOut

# 继承

实现接口：UITransition

# 描述

UIPanel 切换渐隐退出脚本

# **属性**

|                      |            |
| -------------------- | ---------- |
| Color PanelColor     | 背景填充色 |
| Float FadeInDuration | 淡入时间   |
| Float FadOutDuration | 淡出时间   |



# **方法**

|        |                                |
| ------ | ------------------------------ |
| **Do** | 处理切换的行为动作淡入淡出效果 |
