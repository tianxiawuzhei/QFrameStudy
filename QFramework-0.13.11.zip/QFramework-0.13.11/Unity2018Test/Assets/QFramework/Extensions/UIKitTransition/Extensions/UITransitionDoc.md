>作者：vin129     邮箱：515019721@qq.com

# UITransitionExtension

# 描述

> 静态类
>
> 针对 **UITransition** 提供静态方法拓展

# 静态方法

|                    |                                       |
| ------------------ | ------------------------------------- |
| **DoTransition**   | （this **UIPanel**）界面过渡跳转方法  |
| **BindTransition** | （this **Button**）绑定跳转逻辑       |
| **Transition**     | （this **UIPanel**）返回 绑定跳转事件 |

