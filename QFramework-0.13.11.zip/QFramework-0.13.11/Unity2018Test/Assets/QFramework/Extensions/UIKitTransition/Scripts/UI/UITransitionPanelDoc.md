作者：Rycccc     邮箱：huanghonghaoart@gmail.com

# UITransition

# 继承关系

实现接口：UIPanel

# 描述



# **属性**

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |

# **方法**

|      |      |
| ---- | ---- |
|      |      |

